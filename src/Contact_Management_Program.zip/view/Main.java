
import controller.ContactManagement;


public class Main {
    public static void main(String[] args) {
        ContactManagement manager = new ContactManagement();
        manager.run();
    }
}
